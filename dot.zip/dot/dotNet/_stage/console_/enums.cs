namespace enums;

public enum TargetTable
{
    SocrBase,
    AltNames,
    Kladr,
    Streets,
    Doma,
    KladrActual,
    StreetActual,
    DomaActual
}