using System.Text;
using Microsoft.Data.SqlClient;
using DbfDataReader;

namespace KladrImport;

class CommonImport
{

    public CommonImport(ObjectInfo oi)
    {
        this.objectInfo = oi;
    }
    public ObjectInfo objectInfo { get; set; }

    private DbfDataReaderOptions dbfOptions = new DbfDataReaderOptions { SkipDeletedRecords = true };

    public bool ReadDbfInfo()
    {
        long recordCount = 0;
        if (File.Exists(this.objectInfo.SourceFilePath()))
        {
            Console.WriteLine("=====================================================");
            Console.WriteLine($"Обработка файла {this.objectInfo.SourceFilePath()}");
            using (var dbfTable = new DbfTable(this.objectInfo.SourceFilePath(), Encoding.UTF8))
            {
                var header = dbfTable.Header;

                var versionDescription = header.VersionDescription;
                var hasMemo = dbfTable.Memo != null;
                recordCount = header.RecordCount;
                Console.WriteLine($"versionDescription: {versionDescription}\thasMemo: {hasMemo}\trecordCount: {recordCount}");
                foreach (var dbfColumn in dbfTable.Columns)
                {
                    var name = dbfColumn.ColumnName;
                    var columnType = dbfColumn.ColumnType;
                    var length = dbfColumn.Length;
                    var decimalCount = dbfColumn.DecimalCount;
                    Console.WriteLine($"name: {name}\tcolumnType: {columnType}\tlength: {length}\tdecimalCount: {decimalCount}");
                }
            }
            return recordCount > 0;
        }
        else
        {
            Console.WriteLine($"Файл {this.objectInfo.SourceFilePath()} не существует !");
            return false;
        }
    }

    private void clearDestTable()
    {
        using (SqlConnection conn = new SqlConnection(this.objectInfo.ConnectionString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand($"TRUNCATE TABLE {this.objectInfo.DestinationTableName}", conn);
            cmd.ExecuteNonQuery();
        }
    }

    public void BulkImport(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            this.clearDestTable();
        }

        using (var dbfDataReader = new DbfDataReader.DbfDataReader(this.objectInfo.SourceFilePath(), this.dbfOptions))
        {
            using (SqlConnection conn = new SqlConnection(this.objectInfo.ConnectionString))
            {
                conn.Open();
                using (var bulkCopy = new SqlBulkCopy(conn))
                {
                    bulkCopy.DestinationTableName = this.objectInfo.DestinationTableName;
                    try
                    {
                        bulkCopy.WriteToServer(dbfDataReader);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error importing: dbf file: '{this.objectInfo.SourceFilePath()}', exception: {ex.Message}");
                    }
                }
            }
        }
    }
}