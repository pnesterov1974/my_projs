using System.Text;
using Microsoft.Data.SqlClient;
using DbfDataReader;
using KladrImport;

internal class Program
{
    private static string connString = "Data Source=192.168.1.79,1433;Initial Catalog=kladr;User ID=sa;Password=Exptsci123;Trust Server Certificate=True;Connection Timeout=30";

    private static void Main(string[] args)
    {
        Console.WriteLine("-= Import Kladr =-");
        
        ObjectInfo AltNamesObjectInfo = new ObjectInfo
        {
            DestinationTableName = "dbo.[ALTNAMES]",
            SourceDBFFileName = "ALTNAMES.DBF",
            SourceDirPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "/my_dev/files/kladr/",
            ConnectionString = connString
        };

        ObjectInfo KladrObjectInfo = new ObjectInfo 
        {
            DestinationTableName = "dbo.[KLADR]",
            SourceDBFFileName = "KLADR.DBF",
            SourceDirPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "/my_dev/files/kladr/",
            ConnectionString = connString
        };

        ObjectInfo StreetObjectInfo = new ObjectInfo
        {
            DestinationTableName = "dbo.[STREET]",
            SourceDBFFileName = "STREET.DBF",
            SourceDirPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "/my_dev/files/kladr/",
            ConnectionString = connString
        };

        ObjectInfo DomaObjectInfo = new ObjectInfo
        {
            DestinationTableName = "dbo.[DOMA]",
            SourceDBFFileName = "DOMA.DBF",
            SourceDirPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "/my_dev/files/kladr/",
            ConnectionString = connString
        };

        ObjectInfo SocrBaseObjectInfo = new ObjectInfo
        {
            DestinationTableName = "dbo.[SOCRBASE]",
            SourceDBFFileName = "SOCRBASE.DBF",
            SourceDirPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "/my_dev/files/kladr/",
            ConnectionString = connString
        };

        if (tryDbConnection())
        {
            CommonImport sb = new CommonImport(SocrBaseObjectInfo);
            sb.ReadDbfInfo();
            sb.BulkImport();

            CommonImport an = new CommonImport(AltNamesObjectInfo);
            an.ReadDbfInfo();
            an.BulkImport();

            CommonImport kl = new CommonImport(KladrObjectInfo);
            kl.ReadDbfInfo();
            kl.BulkImport();

            CommonImport st = new CommonImport(StreetObjectInfo);
            st.ReadDbfInfo();
            st.BulkImport();

            CommonImport dm = new CommonImport(DomaObjectInfo);
            dm.ReadDbfInfo();
            dm.BulkImport();
        }
    }

    private static bool tryDbConnection()
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            //conn.StateChange += this.Connection_StateChange;
            using (SqlCommand cmd = new SqlCommand("SELECT GETDATE();", conn))
            {
                try
                {
                    conn.Open();
                    var dt = cmd.ExecuteScalar();
                    Console.WriteLine($"Подключено успешно...{dt}");
                    return true;
                }
                catch
                {
                    Console.WriteLine("Подключение не возможно...");
                    return false;
                }
            }
        }
    }
}