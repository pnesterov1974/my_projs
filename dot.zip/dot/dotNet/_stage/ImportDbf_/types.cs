namespace KladrImport;

// public struct SocrBase
// {
//     public string? LEVEL;
//     public string? SCNAME;
//     public string? SOCRNAME;
//     public string? KOD_T_ST;
// }

public struct ObjectInfo 
{
    public string DestinationTableName;
    public string SourceDBFFileName;
    public string SourceDirPath;
    public string ConnectionString;

    public string SourceFilePath()
    { 
        return SourceDirPath + SourceDBFFileName;
    }
}
