using mssqlDb;
using Shared;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseDeveloperExceptionPage();
app.UseSwagger();
app.UseSwaggerUI();

string connString = "Data Source=192.168.1.79,1433;Initial Catalog=kladr;User ID=sa;Password=Exptsci123;Trust Server Certificate=True;Connection Timeout=500";

app.MapGet("/", () => "Hello World!");

app.MapGet("/socrbase", () =>
{
    MsSqlDbObjectOption socrbaseOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [Level],
                   [ScName],
                   [SocrName],
                   [KodTST]
            FROM dbo.[SocrBase];
            """,
        FilenameSubstring = "socrbase"
    };
    KladrData sb = new KladrData(oi: socrbaseOptions);
    return sb.DataAsJson;
});

app.MapGet("/altnames", () =>
{
    MsSqlDbObjectOption altnamesOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [Level],
                   [OldCode],
                   [NewCode]
            FROM dbo.[AltNames];
            """,
        FilenameSubstring = "altnames"
    };
    KladrData an = new KladrData(oi: altnamesOptions);
    return an.DataAsJson;
});

app.MapGet("/kladr", () =>
{
    MsSqlDbObjectOption kladrOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [CODE],
                   [NAME],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD],
                   [STATUS]
            FROM dbo.[KLADR];
            """,
        FilenameSubstring = "kladr"
    };
    KladrData kl = new KladrData(oi: kladrOptions);
    return kl.DataAsJson;
});

app.MapGet("/street", () =>
{
    MsSqlDbObjectOption streetOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [CODE],
                   [NAME],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD]
            FROM dbo.[STREET];
            """,
        FilenameSubstring = "street"
    };
    KladrData st = new KladrData(oi: streetOptions);
    return st.DataAsJson;
});

app.MapGet("/doma", () =>
{
    MsSqlDbObjectOption domaOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [CODE],
                   [NAME],
                   [KORP],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD]
            FROM dbo.[DOMA];
            """,
        FilenameSubstring = "doma"
    };
    KladrData dm = new KladrData(oi: domaOptions);
    return dm.DataAsJson;
});

app.Run();
