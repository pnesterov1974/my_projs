using mssqlDb;
using Shared;

var MyAllowSpecificOrigins = "_AllowAllSpecificOrigins";

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddCors(options =>
{
    options.AddPolicy(name: MyAllowSpecificOrigins, policy => policy.WithOrigins("*")
            .AllowAnyHeader()
            .AllowAnyMethod());
});

var app = builder.Build();

app.UseCors(MyAllowSpecificOrigins);

var config = new ConfigurationBuilder()
                 .AddJsonFile("appsettings.json")
                 .SetBasePath(Directory.GetCurrentDirectory())
                 .Build();
//string connStr = config.GetConnectionString("DefaultConnection");

string connString = "Data Source=192.168.1.79,1433;Initial Catalog=kladr;User ID=sa;Password=Exptsci123;Trust Server Certificate=True;Connection Timeout=500";

app.MapGet("/socrbase", () =>
{
    MsSqlDbObjectOption socrbaseOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [Level],
                   [ScName],
                   [SocrName],
                   [KodTST]
            FROM dbo.[SocrBase];
            """,
        FilenameSubstring = "socrbase"
    };
    KladrData sb = new KladrData(oi: socrbaseOptions);
    return sb.DataAsJson;
});
//.WithName("socrbase")
//.WithOpenApi();

app.MapGet("/altnames", () =>
{
    MsSqlDbObjectOption altnamesOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [Level],
                   [OldCode],
                   [NewCode]
            FROM dbo.[AltNames];
            """,
        FilenameSubstring = "altnames"
    };
    KladrData an = new KladrData(oi: altnamesOptions);
    return an.DataAsJson;
});
//.WithName("altnames")
//.WithOpenApi();


app.MapGet("/kladr", () =>
{
    MsSqlDbObjectOption kladrOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [CODE],
                   [NAME],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD],
                   [STATUS]
            FROM dbo.[KLADR];
            """,
        FilenameSubstring = "kladr"
    };
    KladrData kl = new KladrData(oi: kladrOptions);
    return kl.DataAsJson;
});
//.WithName("kladr")
//.WithOpenApi();

app.MapGet("/street", () =>
{
    MsSqlDbObjectOption streetOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [CODE],
                   [NAME],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD]
            FROM dbo.[STREET];
            """,
        FilenameSubstring = "street"
    };
    KladrData st = new KladrData(oi: streetOptions);
    return st.DataAsJson;
});
//.WithName("street")
//.WithOpenApi();


app.MapGet("/doma", () =>
{
    MsSqlDbObjectOption domaOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [CODE],
                   [NAME],
                   [KORP],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD]
            FROM dbo.[DOMA];
            """,
        FilenameSubstring = "doma"
    };
    KladrData dm = new KladrData(oi: domaOptions);
    return dm.DataAsJson;
});
//.WithName("doma")
//.WithOpenApi();

// app.MapGet("/shirts/{id}",(int id) => {
//     return $"Reading shirt with ID: {id}"
// })

app.Run();