namespace Shared;

public struct MsSqlDbObjectOption
{
    public string ConnectionString;
    public string Sql;
    public string FilenameSubstring;
}

public enum TargetTable
{
    SocrBase,
    AltNames,
    Kladr,
    Streets,
    Doma
}

public struct ObjectInfo 
{
    public string DestinationTableName;
    public string SourceDBFFileName;
    public string SourceDirPath;
    public string ConnectionString;

    public string SourceFilePath()
    { 
        return SourceDirPath + SourceDBFFileName;
    }
}