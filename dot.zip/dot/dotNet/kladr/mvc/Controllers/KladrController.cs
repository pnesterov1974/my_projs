using Microsoft.AspNetCore.Mvc;
using Shared;
using mssqlDb;

namespace mvc.Controllers;

[ApiController]
[Route("api/[controller]")]
public class KladrController : ControllerBase
{
    // public static IConfigurationRoot config = new ConfigurationBuilder()
    //          .AddJsonFile("appsettings.json")
    //          .SetBasePath(Directory.GetCurrentDirectory())
    //          .Build();
    // public static string connStr = config.GetConnectionString("DefaultConnection");
    public static string connString = "Data Source=192.168.1.79,1433;Initial Catalog=kladr;User ID=sa;Password=Exptsci123;Trust Server Certificate=True;Connection Timeout=500";

    [HttpGet]
    [Route("/socrbase")]
    public string GetSocrBase()
    {
        MsSqlDbObjectOption socrbaseOptions = new MsSqlDbObjectOption()
        {
            ConnectionString = connString,
            Sql = """
            SELECT [Level],
                   [ScName],
                   [SocrName],
                   [KodTST]
            FROM dbo.[SocrBase];
            """,
            FilenameSubstring = "socrbase"
        };
        KladrData sb = new KladrData(oi: socrbaseOptions);
        return sb.DataAsJson;
    }

    [HttpGet]
    [Route("/altnames")]
    public string GetAltNames()
    {
        MsSqlDbObjectOption altnamesOptions = new MsSqlDbObjectOption()
        {
            ConnectionString = connString,
            Sql = """
            SELECT [Level],
                   [OldCode],
                   [NewCode]
            FROM dbo.[AltNames];
            """,
            FilenameSubstring = "altnames"
        };
        KladrData an = new KladrData(oi: altnamesOptions);
        return an.DataAsJson;
    }

    [HttpGet]
    [Route("/kladr")]
    public string GetKladr()
    {
        MsSqlDbObjectOption kladrOptions = new MsSqlDbObjectOption()
        {
            ConnectionString = connString,
            Sql = """
            SELECT [CODE],
                   [NAME],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD],
                   [STATUS]
            FROM dbo.[KLADR];
            """,
            FilenameSubstring = "kladr"
        };
        KladrData kl = new KladrData(oi: kladrOptions);
        return kl.DataAsJson;
    }

    [HttpGet]
    [Route("/street")]
    public string GetStreet()
    {
        MsSqlDbObjectOption streetOptions = new MsSqlDbObjectOption()
        {
            ConnectionString = connString,
            Sql = """
            SELECT [CODE],
                   [NAME],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD]
            FROM dbo.[STREET];
            """,
            FilenameSubstring = "street"
        };
        KladrData st = new KladrData(oi: streetOptions);
        return st.DataAsJson;
    }

    [HttpGet]
    [Route("/doma")]
    public string GetDoma()
    {
        MsSqlDbObjectOption domaOptions = new MsSqlDbObjectOption()
        {
            ConnectionString = connString,
            Sql = """
            SELECT [CODE],
                   [NAME],
                   [KORP],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD]
            FROM dbo.[DOMA];
            """,
            FilenameSubstring = "doma"
        };
        KladrData dm = new KladrData(oi: domaOptions);
        return dm.DataAsJson;
    }

    //     [HttpGet]
    //     [Route("/kladr_actual")]
    //     public string GetKladrActual()
    //     {
    //         KladrActualReader klar = new KladrActualReader(KladrController.connStr);
    //         return klar.DataAsJson;
    //     }

    //     [HttpGet]
    //     [Route("/street_actual")]
    //     public string GetStreetActual()
    //     {
    //         StreetActualReader star = new StreetActualReader(KladrController.connStr);
    //         return star.DataAsJson;
    //     }
    // }
}