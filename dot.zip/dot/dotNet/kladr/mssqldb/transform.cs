using Microsoft.Data.SqlClient;
using Shared;

namespace mssqlDb;

public class Transform
{

    public string TargetName { get; set; }
    public string TargetSchema { get; set; }
    public string ConnectionString { get; set; }
    public string Sql { get; set; }

    public Transform(string targetName, string targetSchema, string sql, string connString)
    {
        this.TargetName = targetName;
        this.TargetSchema = targetSchema;
        this.Sql = sql;
        this.ConnectionString = connString;
    }

    public void RunTransformation()
    {
        using (SqlConnection conn = new SqlConnection(this.ConnectionString))
        {

        }
    }

}