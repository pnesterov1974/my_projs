//using System.Data;
using Microsoft.Data.SqlClient;

namespace mssqlDb;

public class DBUtils
{
    public static bool tryDbConnection(string connectionString)
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT GETDATE();", conn))
            {
                try
                {
                    conn.Open();
                    var dt = cmd.ExecuteScalar();
                    Console.WriteLine($"Подключено успешно...{dt}");
                    return true;
                }
                catch
                {
                    Console.WriteLine("Подключение не возможно...");
                    return false;
                }
            }
        }
    }
}