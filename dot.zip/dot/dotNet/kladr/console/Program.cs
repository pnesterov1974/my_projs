using Shared;
using mssqlDb;
using KladrImport;

Console.WriteLine("Hello, World!");

//string connStr = "Data Source=;Initial Catalog=kladr;Integrated Security=True;Pooling=True;Trust Server Certificate=True;Connection Timeout=500";

string connString = "Data Source=192.168.1.79,1433;Initial Catalog=kladr;User ID=sa;Password=Exptsci123;Trust Server Certificate=True;Connection Timeout=500";

// commandline args
// ssis packets
// schedule db
// ----
// learn: mvc (minimal api => mvc), logging, cmd params, configuration

readMsSql();
//importDbf();

void importDbf()
{
    Console.WriteLine("-= Import Kladr from DBF =-");

    ObjectInfo AltNamesObjectInfo = new ObjectInfo
    {
        DestinationTableName = "dbo.[ALTNAMES]",
        SourceDBFFileName = "ALTNAMES.DBF",
        SourceDirPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "/my_dev/files/kladr/",
        ConnectionString = connString
    };

    ObjectInfo KladrObjectInfo = new ObjectInfo
    {
        DestinationTableName = "dbo.[KLADR]",
        SourceDBFFileName = "KLADR.DBF",
        SourceDirPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "/my_dev/files/kladr/",
        ConnectionString = connString
    };

    ObjectInfo StreetObjectInfo = new ObjectInfo
    {
        DestinationTableName = "dbo.[STREET]",
        SourceDBFFileName = "STREET.DBF",
        SourceDirPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "/my_dev/files/kladr/",
        ConnectionString = connString
    };

    ObjectInfo DomaObjectInfo = new ObjectInfo
    {
        DestinationTableName = "dbo.[DOMA]",
        SourceDBFFileName = "DOMA.DBF",
        SourceDirPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "/my_dev/files/kladr/",
        ConnectionString = connString
    };

    ObjectInfo SocrBaseObjectInfo = new ObjectInfo
    {
        DestinationTableName = "dbo.[SOCRBASE]",
        SourceDBFFileName = "SOCRBASE.DBF",
        SourceDirPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "/my_dev/files/kladr/",
        ConnectionString = connString
    };

    ObjectInfo NamesMaoObjectInfo = new ObjectInfo
    {
        DestinationTableName = "dbo.[NameMap]",
        SourceDBFFileName = "NAMEMAP.DBF",
        SourceDirPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "/my_dev/files/kladr/",
        ConnectionString = connString
    };

    if (DBUtils.tryDbConnection(connString))
    {
        CommonImport sb = new CommonImport(SocrBaseObjectInfo);
        sb.ReadDbfInfo();
        sb.BulkImport();

        CommonImport nm = new CommonImport(NamesMaoObjectInfo);
        nm.ReadDbfInfo();
        nm.BulkImport();
        
        CommonImport an = new CommonImport(AltNamesObjectInfo);
        an.ReadDbfInfo();
        an.BulkImport();

        CommonImport kl = new CommonImport(KladrObjectInfo);
        kl.ReadDbfInfo();
        kl.BulkImport();

        CommonImport st = new CommonImport(StreetObjectInfo);
        st.ReadDbfInfo();
        st.BulkImport();
        
        CommonImport dm = new CommonImport(DomaObjectInfo);
        dm.ReadDbfInfo();
        dm.BulkImport();
    }
}

void readMsSql()
{
    Console.WriteLine("-= Read Kladr data from MS SQL =-");

    MsSqlDbObjectOption socrbaseOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [Level],
                   [ScName],
                   [SocrName],
                   [KodTST]
            FROM dbo.[SocrBase];
            """,
        FilenameSubstring = "socrbase"
    };
    KladrData sb = new KladrData(oi: socrbaseOptions);
    sb.SaveJsonSchema();
    sb.SaveJsonData();

    MsSqlDbObjectOption altnamesOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [Level],
                   [OldCode],
                   [NewCode]
            FROM dbo.[AltNames];
            """,
        FilenameSubstring = "altnames"
    };
    KladrData an = new KladrData(oi: altnamesOptions);
    an.SaveJsonSchema();
    an.SaveJsonData();

    MsSqlDbObjectOption nameMapOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [Code],
                   [Name],
                   [ShName],
                   [ScName]
            FROM dbo.[NameMap];
            """,
        FilenameSubstring = "namemap"
    };
    KladrData nm = new KladrData(oi: nameMapOptions);
    nm.SaveJsonSchema();
    nm.SaveJsonData();

    MsSqlDbObjectOption kladrOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [CODE],
                   [NAME],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD],
                   [STATUS]
            FROM dbo.[KLADR];
            """,
        FilenameSubstring = "kladr"
    };
    KladrData kl = new KladrData(oi: kladrOptions);
    kl.SaveJsonSchema();
    kl.SaveJsonData();

    MsSqlDbObjectOption streetOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [CODE],
                   [NAME],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD]
            FROM dbo.[STREET];
            """,
        FilenameSubstring = "street"
    };
    KladrData st = new KladrData(oi: streetOptions);
    st.SaveJsonSchema();
    st.SaveJsonData();

    MsSqlDbObjectOption domaOptions = new MsSqlDbObjectOption()
    {
        ConnectionString = connString,
        Sql = """
            SELECT [CODE],
                   [NAME],
                   [KORP],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD]
            FROM dbo.[DOMA];
            """,
        FilenameSubstring = "doma"
    };
    KladrData dm = new KladrData(oi: domaOptions);
    dm.SaveJsonSchema();
    dm.SaveJsonData();
}
